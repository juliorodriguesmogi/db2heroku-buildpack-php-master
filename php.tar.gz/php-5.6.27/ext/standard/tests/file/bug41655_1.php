<?php
$a=glob("./*.jpeg");
var_dump($a);
echo "Done\n";
?>
